import { Route, Router, Routes } from "react-router-dom";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import Registration from "./components/Registration/Registration";
import EmployeeList from "./components/employeeList/EmployeeList";
import Header from "./Header";

function App() {
  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <div>
        <Header />
        <Routes>
          <Route path="/registration" element={<Registration />} />
          <Route path="/employee-list" element={<EmployeeList />} />
        </Routes>
      </div>
    </LocalizationProvider>
  );
}

export default App;
