import React, { useEffect, useState } from "react";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from "@mui/material";
import "./index.css";
function EmployeeList() {
  const [data, setData] = useState([]);
  useEffect(() => {
    const getData = async () => {
      try {
        const response = await fetch(
          "https://sweede.app/DeliveryBoy/Get-Employee/"
        ); // Replace with your API endpoint
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const result = await response.json(); // Parse the JSON response
        console.log("data", result);
        setData(
          result.map((item) => ({
            name: item.FirstName,
            DOB: item.DOB,
            stDate: item.StartDate,
            endDate: item.EndDate,
            description: item.Description,
          }))
        );
        // You can set the data in a state variable if needed
      } catch (error) {
        console.error("Error fetching data:", error);
        // Handle the error, e.g., set an error state variable
      }
    };

    // Call the getData function to initiate the API request
    getData();
  }, []); // Empty dependency array ensures that this effect runs only once on component mount
  console.log("dataaaa", data);
  return (
    <div className="employeeList-container">
      <h2>Employee List</h2>

      <div className="records-list">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>DOB</TableCell>
              <TableCell>Start Date</TableCell>
              <TableCell>End Date</TableCell>
              <TableCell>Description</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((item) => {
              return (
                <TableRow className="custom-row">
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item.DOB}</TableCell>
                  <TableCell>{item.stDate}</TableCell>
                  <TableCell>{item.endDate}</TableCell>
                  <TableCell>{item.description}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
export default EmployeeList;
