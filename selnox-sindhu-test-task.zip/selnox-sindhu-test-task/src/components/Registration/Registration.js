import React, { useState } from "react";
import Input from "@mui/material/Input";
import axios from "axios";
import { Button } from "@mui/material";
import { Grid } from "@mui/material";
import Typography from "@mui/material/Typography";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import "react-quill/dist/quill.snow.css"; // Import Quill CSS
import ReactQuill from "react-quill"; // Import React-Quill

import "./index.css";

function Registration() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    dob: "",
    study: "",
    startDate: "",
    endDate: "",
    salary: "",
    description: "",
  });

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    console.log(formData); // You can handle form data here
    const isDataValid = isFormDataValid(formData);

    if (isDataValid) {
      // Data is valid, make an Axios call
      axios
        .post("https://sweede.app/DeliveryBoy/Add-Employee/", formData)
        .then((response) => {
          // Handle the response from the server
          console.log("Successfully submitted:", response.data);

          // Optionally, you can reset the form or perform other actions
          // after a successful submission.
        })
        .catch((error) => {
          // Handle errors if the request fails
          console.error("Error submitting data:", error);

          // Optionally, you can display an error message to the user.
        });
    } else {
      // Data is not valid, handle the validation error
      // For example, display an error message to the user
    }
  };

  const handleDatePickers = (value, stateName) => {
    setFormData({ ...formData, [stateName]: value });
  };

  function isFormDataValid(formData) {
    const { firstName, lastName, dob, salary, study } = formData;

    // Check if firstName, lastName, dob, and study are not empty
    if (!firstName || !lastName || !dob) {
      return false;
    }

    // Check if salary is a numeric value (if it's not empty)
    if (salary !== "" && isNaN(salary)) {
      return false;
    }

    // Check if study does not contain numeric characters (if it's not empty)
    if (study !== "" && /\d/.test(study)) {
      return false;
    }

    // All criteria are met, so the data is valid
    return true;
  }

  return (
    <div className="registration-container">
      <h2>Employee Registration Form</h2>
      <div className="registration-form">
        <Grid container spacing={2}>
          <Grid item xs={6} sm={6}>
            <Typography variant="h6" className="custom-typo">
              First Name*
            </Typography>
            <Input
              name="firstName"
              placeholder="Enter your name"
              className="custom-textfield"
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>

          <Grid item xs={6} sm={6}>
            <Typography variant="h6" className="custom-typo">
              Last Name*
            </Typography>
            <Input
              name="lastName"
              placeholder="Enter your last name"
              className="custom-textfield"
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>

          <Grid item xs={12} sm={12}>
            <Typography variant="h6" className="custom-typo">
              DOB
            </Typography>
            <DatePicker
              name="dob"
              placeholder="Enter your dob"
              onChange={(newValue) => {
                handleDatePickers(newValue.toDate(), "dob");
              }}
              fullWidth
            />
          </Grid>

          <Grid item xs={12} sm={12}>
            <Typography variant="h6" className="custom-typo">
              Study
            </Typography>
            <Input
              name="study"
              onChange={handleInputChange}
              placeholder="B.E"
              className="custom-textfield"
              fullWidth
            />
          </Grid>

          <Grid item xs={6} sm={6}>
            <Typography variant="h6" className="custom-typo">
              Start Date
            </Typography>
            <DatePicker
              name="startDate"
              onChange={(newValue) => {
                handleDatePickers(newValue.toDate(), "startDate");
              }}
              fullWidth
            />
          </Grid>

          <Grid item xs={6} sm={6}>
            <Typography variant="h6" className="custom-typo">
              End Date
            </Typography>
            <DatePicker
              name="endDate"
              onChange={(newValue) => {
                handleDatePickers(newValue.toDate(), "endDate");
              }}
              required
              fullWidth
            />
          </Grid>

          <Grid item xs={12} sm={12}>
            <Typography variant="h6" className="custom-typo">
              Current Salary
            </Typography>
            <Input
              name="salary"
              placeholder="30000"
              onChange={handleInputChange}
              className="custom-textfield"
              fullWidth
            />
          </Grid>

          <Grid item xs={12} sm={12}>
            <Typography variant="h6" className="custom-typo">
              Description
            </Typography>
            <ReactQuill
              onChange={(e) => setFormData({ ...formData, description: e })}
              modules={{
                toolbar: [
                  ["bold", "italic", "underline", "strike"], // Text formatting options
                  [{ list: "ordered" }, { list: "bullet" }], // Lists
                  ["link"], // Link
                  ["clean"], // Remove formatting
                ],
              }}
              rows={10}
              style={{ height: "150px" }}
            />
          </Grid>
        </Grid>
      </div>
      <div className="button-container">
        <Button variant="" color="">
          Cancel
        </Button>
        <Button variant="" color="" onClick={handleSave}>
          Save
        </Button>
      </div>
    </div>
  );
}

export default Registration;
